from importlib.resources import contents
from math import prod
from unicodedata import name
import requests
from bs4 import BeautifulSoup

url="https://www.amazon.in/s?k=bags&crid=2M096C61O4MLT&qid=1653308124&sprefix=ba%2Caps%2C283&ref=sr_pg_1"
final_data=[]
for page in range(1,21):
     f = open("amazon.html", "r")
     htmlcontent=f.read()
     # r=requests.get("https://www.amazon.in")
     # htmlcontent=r.content
     # print(htmlcontent)
     # a-size-medium a-color-base a-text-normal
     soup = BeautifulSoup(htmlcontent, 'html.parser')
     tag=soup.find('href')
     print(tag)
     

     # product_listing=soup.find_all(  'div',class_="a-section a-spacing-small a-spacing-top-small")
     # # print(product_listing)
     # products_data=[]

     # for product in product_listing:
     #      product_data={}
     
     #      # print(type(product))
     #      # prod_soup = BeautifulSoup(product, 'html.parser')
     #      product_name=product.find_all(  'span',class_="a-size-medium a-color-base a-text-normal")
     #      product_rating=product.find_all(  'span',class_="a-icon-alt")
     #      product_price=product.find_all(  'span',class_="a-price-whole")
     #      product_reviews=product.find_all(  'span',class_="a-size-base s-underline-text")
     #      product_url=product.find_all(  'a',class_="a-size-mini a-spacing-none a-color-base s-line-clamp-2")


     #      if not product_name or not product_rating or not product_price or not product_reviews or not product_url:
     #           continue
     #      product_data['name'] = product_name[0].get_text()
     #      product_data['rating'] = product_rating[0].get_text()
     #      product_data['price'] = product_price[0].get_text()
     #      product_data['reviews'] = product_reviews[0].get_text()
     #      product_data['url'] = product_url[0].get_text()
     #      f = open("Amazon.html", "r")
     #      htmlcontent=f.read()
     #      soup = BeautifulSoup(htmlcontent, 'html.parser')
     #      product_description=soup.find_all(  'div', id="productDescription_feature_div")
          
     #      products_detail=soup.find_all(  'div', id="detailBullets_feature_div")
     #      if products_detail:
     #           for li_tag in products_detail[0].find_all('ul', {'class':'a-unordered-list a-nostyle a-vertical a-spacing-none detail-bullet-list'}):
     #                for span_tag in li_tag.find_all('li'):
     #                          # field = span_tag.find('span', {'class':'a-list-item'}).text.replace(" ", "").replace('\n','')
     #                     field = span_tag.find('span', {'class':'a-list-item'}).text.split(':')
     #                     new_field=''.join(e for e in field[0] if e.isalnum())
     #                     if new_field in ('Manufacturer','ASIN'):
     #                          product_data[new_field] = field[1].replace(" ", "").replace('\n','')
                              
                    

                    

     #      products_data.append(product_data)
     #      # print(products_data)
     # final_data.extend(products_data)
     













